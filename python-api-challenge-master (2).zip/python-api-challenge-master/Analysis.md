# ANALYSIS # #### (as 7/15/2020) ####

### TEMPERATURE AND LATITUDE ###
At this time of the year, the temperature has a "bell shape" and is almost symmetrical with the 0 Degree Latitude being the axis. The highest temperature are around the Equator. the tilt of the earth makes that the Southern Hemisphere is in winter and the Northern Hemisphere is in summer. If it was winter in the Northern Hemisphere, we could observe a negative regression with more data point grouped in the high temperature in the Southern Hemisphere and the opposite in the Northern Hemisphere.

### CLOUDINESS AND LATITUDE ###
There is no strong relationship between Latitude and cloudiness. However, there is a concentration at the 60 degree Latitude and the Equator. Because, the air rises, the atmospheric pressure is low and the climate is wet, we have more clouds in these regions. On the scattered plot, we can observe a concentration of cities of a 100% cloudiness at the Equator and the 60 degree Latitude.

### WIND SPEED AND LATITUDE ###
There is no strong relation between wind speed and Latitude. More data points are between 0mph and 10mph. However, we can observe that there are data concentration at the Equator, the 60 degree Latitude. This is explained by the jet streams who met at these latitude (60 degree Lat.: where Westlies stream and Polar Easteries meet / Equator: it is where the North/East and South/East trade winds meet). If we were in in the winter period we would observe more strong winds around the 30 and 40 degree Latitude and on the 60 degree Latitude.